//for(iniciador, condição, incremento){
   // execução de algo
    //condição: comparação, 

//let nome = "joao"
//for(let i = 3; i >2; i++){
    //console.log("a condição deu verdadeira")
//}

//for(let i =10; i>2; i--){
    //console.log(i)
//}

//for(let i =1; i<=10; i++){
  //  console.log("FOR =>" + i)
//}
    

//let j = 1
//while(j<=10){
  //  console.log("WHILE" + J)
    //j++
//}

//let sexo = "masculino"

//if(sexo == "masculino"){
  //  console.log("masculino")
//} else if(sexo == "feminino"){
 //   console.log("feminino")
//}else{ // else não tem comparação e é usado só uma vez e no final
//console.log("sexo não reconhecido")
//}

