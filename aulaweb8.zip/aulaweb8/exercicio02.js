let n = 2

if(n == 1){
    console.log(n + " - Domingo")
} else if(n == 2){
    console.log(n + " - Segunda")
}else if(n == 3){
    console.log(n + " - Terça")
} else if(n == 4){
    console.log(n + " - Quarta")
} else if(n == 5){
    console.log(n + " - Quinta")
} else if(n == 6){
    console.log(n + " - Sexta")
} else if(n == 7){
    console.log(n + " - Sabado")
}


