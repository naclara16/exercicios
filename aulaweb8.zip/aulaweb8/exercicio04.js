//let base = 2
//let expoente = 4

//console.log(base ** expoente )

let base = 2
let expoente = 5
let resultado = 1

// 2**5 = 2x2x2x2x2

for(let i =1; i <=expoente; i++){
    resultado = resultado * base
    // resultado *= base
}
console.log(resultado)