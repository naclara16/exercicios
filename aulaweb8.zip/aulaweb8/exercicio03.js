let n = 104

if(n % 2 === 0){
    console.log("O numero " + n + " é par ")
}else{
    console.log(" O numero " + n + " é impar ")
}

