let letra = "A"

if(letra == "A"&&"E"&&"I"&&"O"&&"U"){
    console.log("A letra " + letra + " é vogal")
} else if(letra == "B","C","D","F","G","H","J","k","L","M","N","P","Q","R","S","T","V","W","X","Y","Z"){
    console.log("A letra " + letra + " é consoante" )
}else{
    console.log("letra não reconhecida")
}

//let letra = "A"

//if(letra == "a" || letra == "e" || letra == "i" || letra == "o"|| letra "u" ){
 //  console.log("A letra " + letra + "é vogal")
//} else if(letra == "é consoante"){
//    console.log("A letra " + letra + "é consoante" )
//}
  